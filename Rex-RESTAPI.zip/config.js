module.exports = {
    creator: 'Arnov',
  };
  